// index.js
import express from "express";
import cors from "cors";
import fs from "fs";
import path from 'path';
import crypto from 'crypto';
import twilio from 'twilio'; // Twilio Import

// ... existing imports ...

import pino from "pino";
import qrcode from "qrcode-terminal";

/* ========== Structured Logger (pino JSON) ========== */
const LOG_DIR = process.env.LOG_DIR || path.join(process.cwd(), 'logs');
try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch {}

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  timestamp: pino.stdTimeFunctions.isoTime,
  base: { service: 'superparty-backend', env: process.env.NODE_ENV || 'production' },
  transport: process.env.NODE_ENV !== 'production' ? {
    target: 'pino-pretty',
    options: { colorize: true }
  } : undefined,
});

/* ========== Prometheus Metrics (prom-client) ========== */
import promClient from 'prom-client';

const metricsRegistry = new promClient.Registry();
promClient.collectDefaultMetrics({ register: metricsRegistry });

const httpRequestsTotal = new promClient.Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'path', 'status'],
  registers: [metricsRegistry],
});

const httpRequestDuration = new promClient.Histogram({
  name: 'http_request_duration_seconds',
  help: 'HTTP request duration in seconds',
  labelNames: ['method', 'path'],
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
  registers: [metricsRegistry],
});

const whatsappMessagesTotal = new promClient.Counter({
  name: 'whatsapp_messages_total',
  help: 'Total WhatsApp messages processed',
  labelNames: ['direction'],
  registers: [metricsRegistry],
});

const canonicalMismatchTotal = new promClient.Counter({
  name: 'canonical_mismatch_total',
  help: 'Firestore writes where convoId did not match canonical JID (indicates amestec risk)',
  labelNames: ['route'],
  registers: [metricsRegistry],
});

/**
 * Anti-amestec: log + guardrail for every media operation.
 * Increments canonical_mismatch_total if convoId doesn't match expected canonical form.
 */
function logMediaOp(route, { inputJid, canonicalJid, accountId, convoId, msgId, storagePath, requestId }) {
  const expected = accountId ? `${accountId}_${canonicalJid}` : canonicalJid;
  const mismatch = convoId && convoId !== expected;
  if (mismatch) {
    canonicalMismatchTotal.inc({ route });
    logger.warn({ route, inputJid, canonicalJid, accountId, convoId, expected, msgId, storagePath, requestId, mismatch: true },
      `[CANONICAL MISMATCH] convoId="${convoId}" != expected="${expected}"`);
  } else {
    logger.info({ route, inputJid, canonicalJid, accountId, convoId, msgId, storagePath, requestId, mismatch: false },
      `[MediaOp] ${route}`);
  }
  return mismatch;
}
import { createRequire } from "module";
const require = createRequire(import.meta.url);
import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  downloadAndProcessHistorySyncNotification,
  downloadMediaMessage,
} from "@whiskeysockets/baileys";
import { makeCustomStore } from "./store.js";
// import { logMessage } from "./sheets.js"; 
import admin from "firebase-admin";
// ── Firebase Admin default app init (required for admin.auth().verifyIdToken) ──
if (!admin.apps.length) {
  const _fbKey = require('./firebase-service-account.json');
  admin.initializeApp({ credential: admin.credential.cert(_fbKey) });
}

import { SessionManager } from "./session-manager.js"; // Import SessionManager

import * as Sentry from '@sentry/node';
if (process.env.SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV || 'production',
    tracesSampleRate: 0.05,
  });
}

/* ========== Config ========== */
const PORT = process.env.PORT || 3001;
const BASE_URL = process.env.PUBLIC_URL || 'http://46.225.182.127:3001';
// In-memory cache: last registered VoIP identity (updated on registerDevice)
// In-memory cache: last registered VoIP identity (updated on registerDevice)
let _lastRegisteredIdentity = null;
const _confLegs = {}; // { extSid: { agentSid, confName } }
const _confAgentSids = new Set(); // SIDs of active conference agent legs — only these get FCM call_ended
const LID_MAPPING_FILE = "lid_mappings.json";
const STORE_FILE = "baileys_store_multi.json";

/* ========== Firebase Admin Init ========== */
import { initFirebase, syncMessageToFirestore, uploadMediaToStorage, getSignedMediaUrl, setCanonicalMismatchCallback } from "./firebase-sync.js";
import multer from "multer";
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 }, storage: multer.memoryStorage() });

// Init immediately
const db = initFirebase(); 

// Wire anti-amestec callback: increment Prometheus counter on canonical mismatch
setCanonicalMismatchCallback((route, details) => {
  canonicalMismatchTotal.inc({ route });
  logger.warn({ ...details, route, mismatch: true }, `[CANONICAL MISMATCH] in ${route}`);
});

/* ========== Lid overrides (file-based) ========== */
let lidOverrides = {};
const phoneToLidMap = new Map();

function loadLidOverrides() {
  try {
    if (fs.existsSync(LID_MAPPING_FILE)) {
      const raw = fs.readFileSync(LID_MAPPING_FILE, "utf8");
      lidOverrides = raw ? JSON.parse(raw) : {};
    } else {
      lidOverrides = {};
    }
  } catch (e) {
    console.error("Failed to load lid_mappings.json:", e);
    lidOverrides = {};
  }
  phoneToLidMap.clear();
  for (const [lid, phoneJid] of Object.entries(lidOverrides)) {
    phoneToLidMap.set(phoneJid, lid);
  }
}
function saveLidOverrides() {
  try {
    fs.writeFileSync(LID_MAPPING_FILE, JSON.stringify(lidOverrides, null, 2), "utf8");
  } catch (e) {
    console.error("Failed to write lid_mappings.json:", e);
  }
  phoneToLidMap.clear();
  for (const [lid, phoneJid] of Object.entries(lidOverrides)) {
    phoneToLidMap.set(phoneJid, lid);
  }
}
loadLidOverrides();

/* ========== Store setup ========== */
const store = makeCustomStore();
if (fs.existsSync(STORE_FILE)) {
  try { store.readFromFile(STORE_FILE); } catch (e) { console.error("Failed to read store:", e); }
}

/* Debounced writes */
let pendingWrite = null;
function scheduleStoreWrite(delay = 2000) {
  if (pendingWrite) return;
  pendingWrite = setTimeout(() => {
    try {
      store.writeToFile(STORE_FILE);
    } catch (e) {
      console.error("store.writeToFile error:", e);
    } finally {
      clearTimeout(pendingWrite);
      pendingWrite = null;
    }
  }, delay);
}
setInterval(() => { try { store.writeToFile(STORE_FILE); } catch (e) {} }, 10000);

/* ========== Google Sync Init ========== */
// import googleSync from "./google-sync.js"; // Removed duplicate
// googleSync.initGoogleSync().catch(e => console.error("Failed to init Google Sync:", e));

/* ========== Session Manager ========== */
const sessionManager = new SessionManager(store);
// Inject resolveCanonicalJid so inbound messages are canonicalized before Firestore write
sessionManager._resolveCanonicalJid = resolveCanonicalJid;
// Start initialization
sessionManager.init().catch(err => console.error("Failed to init SessionManager:", err));


/* ========== Helpers to access store (Map or Object) ========== */
function getContact(id) {
  if (!store || !store.contacts) return null;
  if (store.contacts instanceof Map) return store.contacts.get(id);
  return store.contacts[id];
}
function setContact(id, value) {
  if (store.contacts instanceof Map) store.contacts.set(id, value);
  else store.contacts[id] = value;
}
function getAllContactsArray() {
  if (!store || !store.contacts) return [];
  if (store.contacts instanceof Map) return Array.from(store.contacts.values());
  return Object.values(store.contacts);
}
function getMessagesForJid(jid) {
  if (!store || !store.messages) return [];
  if (store.messages instanceof Map) return store.messages.get(jid) || [];
  return store.messages[jid] || [];
}
function getChatsArray() {
  if (!store || !store.chats) return [];
  if (store.chats instanceof Map) return Array.from(store.chats.values());
  return Object.values(store.chats);
}

/* ========== Canonicalization logic ========== */
function resolveCanonicalJid(jid) {
  if (!jid) return jid;
  if (jid.endsWith("@g.us")) return jid; // groups keep their own id

  const suffix = jid.split("@")[1] || "";

  if (suffix === "s.whatsapp.net" || suffix === "c.us") {
    return jid;
  }

  if (suffix === "lid") {
    const contact = getContact(jid);
    if (contact && contact.phoneNumber) return contact.phoneNumber;
    if (lidOverrides[jid]) return lidOverrides[jid];
    const contacts = getAllContactsArray();
    for (const c of contacts) {
      if (!c) continue;
      if (c.id === jid && c.phoneNumber) return c.phoneNumber;
    }
    for (const c of contacts) {
      if (!c) continue;
      if (c.lid && c.lid === jid && c.phoneNumber) return c.phoneNumber;
    }
    for (const c of contacts) {
      if (!c) continue;
      if (c.phoneNumber && typeof c.phoneNumber === "string") {
        const candidatePhone = c.phoneNumber.split("@")[0];
        const lidNumeric = jid.split("@")[0];
        if (String(candidatePhone).includes(String(lidNumeric).slice(-6)) ) {
          return c.phoneNumber;
        }
      }
    }
    for (const [k, v] of Object.entries(lidOverrides)) {
      if (k === jid) return v;
    }
    return jid;
  }

  const c = getContact(jid);
  if (c && c.phoneNumber) return c.phoneNumber;
  const phonePart = jid.split("@")[0];
  for (const contact of getAllContactsArray()) {
    if (!contact) continue;
    if (contact.phoneNumber && contact.phoneNumber.split("@")[0] === phonePart) return contact.phoneNumber;
    if (contact.id && contact.id.split("@")[0] === phonePart) return contact.id;
  }
  return jid;
}

/* ========== JID Resolution Helpers ========== */
function findPartnerJids(target) {
  const partners = new Set();
  partners.add(target);

  // canonical
  try {
    const canonical = resolveCanonicalJid(target);
    if (canonical) partners.add(canonical);
  } catch (e) {}

  // dacă target e phone, adaugă lid-urile care au phoneNumber
  if (target.endsWith('@s.whatsapp.net')) {
    const contacts = store.contacts instanceof Map ? Array.from(store.contacts.values()) : Object.values(store.contacts || {});
    for (const c of contacts) {
      if (!c) continue;
      if (c.phoneNumber === target) partners.add(c.id);
      if (c.id && c.id.endsWith('@lid') && c.phoneNumber === target) partners.add(c.id);
    }
    // și mapping file
    for (const [lid, phone] of Object.entries(lidOverrides || {})) {
      if (phone === target) partners.add(lid);
    }
  }

  // dacă target e lid, adaugă phone din contact sau din lidOverrides
  if (target.endsWith('@lid')) {
    const contact = store.contacts instanceof Map ? store.contacts.get(target) : (store.contacts || {})[target];
    if (contact && contact.phoneNumber) partners.add(contact.phoneNumber);
    if (lidOverrides && lidOverrides[target]) partners.add(lidOverrides[target]);
  }

  return Array.from(partners);
}


// import googleSync from "./google-sync.js";

/* ========== Express app ========== */
const app = express();
app.use(cors());
app.use(express.json());
app.use('/media', express.static(path.join(process.cwd(), 'public', 'media')));

// ─── Boot Safety ─────────────────────────────────────────
try { fs.mkdirSync(path.join(process.cwd(), 'public', 'media'), { recursive: true }); } catch {}

// ─── Admin Token Middleware ──────────────────────────────
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
if (!ADMIN_TOKEN) logger.warn('⚠️ ADMIN_TOKEN not set — admin endpoints will reject all requests');
function requireAdminToken(req, res, next) {
  // Allow token via header or query param
  const auth = req.headers.authorization;
  const qToken = req.query.token;
  const token = (auth && auth.startsWith('Bearer ') ? auth.split('Bearer ')[1] : null) || qToken;
  if (token !== ADMIN_TOKEN) {
    return res.status(401).json({ error: 'unauthorized', message: 'Missing or invalid admin token' });
  }
  next();
}

// ─── Rate Limiter for regenerate ─────────────────────────
const _regenRateLimit = new Map();
function regenRateLimit(req, res, next) {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();
  const WINDOW_MS = 60_000;
  const MAX_PER_WINDOW = 10;
  let entry = _regenRateLimit.get(ip);
  if (!entry || now - entry.windowStart > WINDOW_MS) {
    entry = { count: 0, windowStart: now };
    _regenRateLimit.set(ip, entry);
  }
  entry.count++;
  if (entry.count > MAX_PER_WINDOW) {
    return res.status(429).json({ error: 'rate_limited', message: 'Too many requests. Wait 60s.', retryAfterMs: WINDOW_MS - (now - entry.windowStart) });
  }
  next();
}

/* ========== RequestId + Metrics Middleware ========== */
app.use((req, res, next) => {
  // Generate or propagate requestId
  const requestId = req.headers['x-request-id'] || crypto.randomUUID();
  req.requestId = requestId;
  res.setHeader('X-Request-Id', requestId);

  // Timing
  const startTime = process.hrtime.bigint();

  // Log + metrics on response finish
  res.on('finish', () => {
    const durationNs = Number(process.hrtime.bigint() - startTime);
    const durationS = durationNs / 1e9;
    const routePath = req.route?.path || req.path || req.url;

    // Prometheus metrics
    httpRequestsTotal.inc({ method: req.method, path: routePath, status: res.statusCode });
    httpRequestDuration.observe({ method: req.method, path: routePath }, durationS);

    // Structured JSON log
    logger.info({
      requestId,
      method: req.method,
      url: req.url,
      statusCode: res.statusCode,
      duration: Math.round(durationS * 1000),
      ip: req.ip || req.connection?.remoteAddress,
    }, `${req.method} ${req.url} ${res.statusCode} ${Math.round(durationS * 1000)}ms`);
  });

  next();
});

/* ========== Twilio Config (from env only — no hardcoded secrets) ========== */
const TWILIO_SID = process.env.TWILIO_SID;
const TWILIO_TOKEN = process.env.TWILIO_TOKEN;
const API_KEY_SID = process.env.TWILIO_API_KEY_SID;
const API_KEY_SECRET = process.env.TWILIO_API_KEY_SECRET;
const TWIML_APP_SID = process.env.TWIML_APP_SID;
if (!TWILIO_SID || !TWILIO_TOKEN) logger.warn('⚠️ TWILIO_SID/TWILIO_TOKEN not set — Twilio calls will fail');
const twilioClient = (TWILIO_SID && TWILIO_TOKEN) ? twilio(TWILIO_SID, TWILIO_TOKEN) : null;

/* ========== Twilio Webhook ========== */
// Add urlencoded for Twilio
app.use(express.urlencoded({ extended: true }));


// ═══════════════════════════════════════════════════════════════════════════
// VOICE CALL CENTER — Clean rebuild (Feb 2026)
// Routes: incoming, status, client-status, recording-status,
//         registerDevice, getVoipToken, calls, calls/:sid, recording/:sid
// NO conference, NO park-fallback, NO bridge-agent, NO superparty_admin
// ═══════════════════════════════════════════════════════════════════════════

// ── 1. INCOMING CALL WEBHOOK (Twilio → app) ──────────────────────────────────
app.post('/api/voice/incoming', async (req, res) => {
  const { From, To, CallSid, Direction } = req.body;
  const twiml = new twilio.twiml.VoiceResponse();

  // ── OUTGOING CALL: Flutter SDK → TwiML App → this webhook ──────────────────
  // When Flutter calls TwilioVoice.instance.call.place(to: '+40...'),
  // Twilio SDK sends Direction='outbound-api' and To=the destination number
  const isOutgoing = Direction === 'outbound-api' || (From && From.startsWith('client:'));
  if (isOutgoing) {
    const dest = To;
    if (!dest || dest.trim() === '') {
      console.warn('[Voice] Outgoing: no destination number');
      twiml.say({ language: 'ro-RO' }, 'Număr invalid.');
      twiml.hangup();
      res.type('text/xml');
      return res.send(twiml.toString());
    }
    console.log(`[Voice] Outgoing call From:${From} To:${dest} SID:${CallSid}`);
    const callerIdOut = process.env.TWILIO_CALLER_ID || '+40373805828';
    const dial = twiml.dial({ callerId: callerIdOut, timeout: 30,
      action: (process.env.PUBLIC_URL || 'http://46.225.182.127') + '/api/voice/status',
      method: 'POST',
    });
    dial.number({
      statusCallback: (process.env.PUBLIC_URL || 'http://46.225.182.127') + '/api/voice/status',
      statusCallbackEvent: 'answered completed',
      statusCallbackMethod: 'POST',
    }, dest);
    res.type('text/xml');
    return res.send(twiml.toString());
  }

  // ── INCOMING CALL: External caller → Twilio number → this webhook ──────────
  // Reject ALL calls FROM our own Twilio numbers.
  // These are internal Twilio routing calls (conference bridge, intermediate hops)
  // that must NOT trigger another Dial to the VoIP client (causes double/triple ring).
  // Direct conference pushes go to Flutter via FCM — they do NOT hit this webhook.
  const ownNumbers = (process.env.TWILIO_NUMBERS || '+40373805828,+40373810882').split(',').map(n => n.trim());
  if (ownNumbers.includes(From) || From === To) {
    console.warn(`[Voice] Internal/loop call From:${From} To:${To} — hangup`);
    twiml.hangup();
    res.type('text/xml');
    return res.send(twiml.toString());
  }

  console.log(`[Voice] Incoming call From:${From} To:${To} SID:${CallSid}`);

  // Get identity from in-memory cache (set by registerDevice)
  let cachedId = _lastRegisteredIdentity;
  let clientIdentity = cachedId
    ? (typeof cachedId === 'object' ? cachedId.identity : cachedId)
    : null;

  // Cache empty (server restarted) — do fast Firestore lookup as fallback
  if (!clientIdentity) {
    console.warn('[Voice] Cache empty — querying Firestore for latest device...');
    try {
      const usersSnap = await db.collection('users').limit(30).get();
      let bestTs = 0;
      for (const userDoc of usersSnap.docs) {
        const devSnap = await db.collection('users').doc(userDoc.id)
          .collection('devices').orderBy('lastSeen', 'desc').limit(1).get();
        if (!devSnap.empty) {
          const d = devSnap.docs[0].data();
          if (d.identity) {
            const ts = d.lastSeen?.toMillis ? d.lastSeen.toMillis() : 0;
            if (ts > bestTs) {
              bestTs = ts;
              clientIdentity = d.identity;
              _lastRegisteredIdentity = d; // cache for next call
            }
          }
        }
      }
    } catch (e) { console.error('[Voice] Firestore fallback error:', e.message); }
  }

  if (!clientIdentity) {
    console.warn('[Voice] No registered device found anywhere — rejecting');
    twiml.say({ language: 'ro-RO' }, 'Ne pare rău, nu există niciun operator disponibil. Vă rugăm să încercați mai târziu.');
    twiml.hangup();
    res.type('text/xml');
    return res.send(twiml.toString());
  }

  console.log(`[Voice] Dialing: ${clientIdentity}`);

  // Simple direct dial — action URL ensures client call ends when agent hangs up
  const callerId = From;
  const BASE = process.env.PUBLIC_URL || 'http://46.225.182.127';
  const dial = twiml.dial({ callerId, timeout: 30, action: `${BASE}/api/voice/dial-complete`, method: 'POST' });
  dial.client({
    statusCallback: (process.env.PUBLIC_URL || 'http://46.225.182.127:3001') + '/api/voice/client-status',
    statusCallbackEvent: 'initiated ringing answered completed',
    statusCallbackMethod: 'POST',
  }, clientIdentity);

  // Respond to Twilio IMMEDIATELY (critical — delay causes timeout + no audio)
  res.type('text/xml');
  res.send(twiml.toString());

  // Log to Firestore AFTER response (async — does not delay TwiML)
  setImmediate(async () => {
    try {
      await db.collection('active_incoming_calls').doc(CallSid).set({
        callSid: CallSid, from: From, to: To,
        identity: clientIdentity,
        status: 'ringing',
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });
    } catch (e) { console.error('[Voice] Firestore log error:', e.message); }
  });
});

// ── 2. CALL STATUS CALLBACK (Twilio → server when call completes) ──────────
                                                               


// When agent VoIP disconnects, this action fires → hangup parent call (client side)

// Force-hangup: Flutter calls this when user presses hangup (Huawei SDK workaround)
// Terminates ALL active in-progress calls via Twilio REST API
app.post('/api/voice/forceHangup', async (req, res) => {
  const { callSid, terminateAll } = req.body;
  console.log(`[Voice] forceHangup: callSid=${callSid} terminateAll=${terminateAll}`);

  let terminated = 0;
  try {
    // Strategy: terminate ALL in-progress calls to/from our numbers
    const activeCalls = await twilioClient.calls.list({ status: 'in-progress', limit: 10 });
    for (const call of activeCalls) {
      console.log(`[Voice] forceHangup: killing ${call.sid} (${call.from} -> ${call.to})`);
      try {
        await twilioClient.calls(call.sid).update({ status: 'completed' });
        terminated++;
      } catch(e) { console.warn(`[Voice] Could not terminate ${call.sid}:`, e.message); }
    }
    console.log(`[Voice] forceHangup: terminated ${terminated} calls`);
    res.json({ success: true, terminated });
  } catch(e) {
    console.error('[Voice] forceHangup error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/voice/dial-complete', (req, res) => {
  const { DialCallStatus, CallSid } = req.body;
  console.log(`[Voice] dial-complete: DialCallStatus=${DialCallStatus} parent=${CallSid}`);
  const twiml = new twilio.twiml.VoiceResponse();
  twiml.hangup();
  res.type('text/xml').send(twiml.toString());
});

app.post('/api/voice/status', async (req, res) => {
  const { CallSid, CallStatus, From, To, CallDuration, RecordingUrl } = req.body;
  res.sendStatus(200);

  console.log(`[Voice] Status: ${CallStatus} SID:${CallSid} Duration:${CallDuration || 0}s`);

  // Save to calls history
  try {
    const cleanFrom = From ? From.replace(/\D/g, '') : '';
    await db.collection('calls').doc(CallSid).set({
      callSid: CallSid, from: From || '', fromClean: cleanFrom,
      to: To || '', status: CallStatus || '',
      duration: parseInt(CallDuration || '0', 10),
      recordingUrl: RecordingUrl || null,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });
  } catch (e) { console.error('[Voice] Calls save error:', e.message); }

  // If this is an ext conference leg ending → terminate agent leg so screen closes
  if (_confLegs[CallSid] && ['completed', 'failed', 'no-answer', 'busy', 'canceled'].includes(CallStatus)) {
    const { agentSid } = _confLegs[CallSid];
    delete _confLegs[CallSid];
    console.log(`[Voice] Conf ext ended (${CallStatus}) → terminating agent ${agentSid}`);
    try { await twilioClient.calls(agentSid).update({ status: 'completed' }); }
    catch(e) { console.warn('[Voice] Agent termination error:', e.message); }
  }

  // Update active_incoming_calls & send FCM when call ends
  const terminalStatuses = ['completed', 'failed', 'canceled', 'no-answer', 'busy'];
  if (terminalStatuses.includes(CallStatus)) {
    // Update Firestore
    try {
      await db.collection('active_incoming_calls').doc(CallSid).update({
        status: CallStatus,
        endTime: admin.firestore.FieldValue.serverTimestamp(),
        duration: parseInt(CallDuration || '0', 10),
      });
    } catch (e) { /* doc may not exist */ }

    // Send FCM ONLY for tracked calls:
    // 1. Conference agent legs (in _confAgentSids)
    // 2. Incoming calls (doc exists in active_incoming_calls Firestore)
    // Do NOT send FCM for intermediate Twilio routing calls (prevents false screen close)
    const isTrackedAgentCall = _confAgentSids.has(CallSid);
    if (isTrackedAgentCall) _confAgentSids.delete(CallSid);

    let shouldSendFCM = isTrackedAgentCall;
    if (!shouldSendFCM) {
      try {
        const fiDoc = await db.collection('active_incoming_calls').doc(CallSid).get();
        if (fiDoc.exists) shouldSendFCM = true;
      } catch(e) { /* ignore */ }
    }

    if (shouldSendFCM) {
      const cached = _lastRegisteredIdentity;
      if (cached && typeof cached === 'object' && cached.userId && cached.deviceId) {
        try {
          const devDoc = await db.collection('users').doc(cached.userId)
            .collection('devices').doc(cached.deviceId).get();
          if (devDoc.exists && devDoc.data().fcmToken) {
            await admin.messaging().send({
              token: devDoc.data().fcmToken,
              android: { priority: 'high' },
              data: { type: 'call_ended', callSid: CallSid, callStatus: CallStatus },
            });
            console.log(`[Voice] FCM call_ended sent for SID:${CallSid}`);
          }
        } catch (e) { console.error('[Voice] FCM send error:', e.message); }
      }
    } else {
      console.log(`[Voice] FCM call_ended SKIPPED for untracked SID:${CallSid} (${CallStatus})`);
    }
  }
});

// ── 3. CLIENT STATUS (Twilio → server for VoIP client leg status) ──────────
app.post('/api/voice/client-status', async (req, res) => {
  const { CallSid, CallStatus, Client } = req.body;
  res.sendStatus(200);
  console.log(`[Voice] Client status: ${CallStatus} SID:${CallSid} Client:${Client}`);

  // Update active_incoming_calls with client status
  try {
    await db.collection('active_incoming_calls').doc(CallSid).update({
      clientStatus: CallStatus,
      clientUpdatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  } catch (e) { /* doc may not exist */ }
});

// ── 4. RECORDING STATUS ───────────────────────────────────────────────────────
app.post('/api/voice/recording-status', async (req, res) => {
  const { RecordingSid, RecordingUrl, RecordingStatus, CallSid, RecordingDuration } = req.body;
  res.sendStatus(200);
  if (RecordingStatus !== 'completed') return;
  console.log(`[Voice] Recording ready: ${RecordingUrl}`);
  try {
    await db.collection('calls').doc(CallSid).update({
      recordingUrl: RecordingUrl,
      recordingSid: RecordingSid,
      recordingDuration: parseInt(RecordingDuration || '0', 10),
    });
  } catch (e) { console.error('[Voice] Recording update error:', e.message); }
});

// ── 5. REGISTER DEVICE (Flutter app → server on startup) ─────────────────────

// ── OUTGOING CALL: Simple Dial approach ──────────────────────────────────────
// ONE call to external, when they answer → bridge to VoIP client
app.post('/api/voice/makeCall', async (req, res) => {
  const { to, userId } = req.body;
  if (!to) return res.status(400).json({ error: 'Missing: to' });

  try {
    let cachedId = _lastRegisteredIdentity;
    let clientIdentity = cachedId
      ? (typeof cachedId === 'object' ? cachedId.identity : cachedId)
      : null;

    if (!clientIdentity && userId) {
      try {
        const devSnap = await db.collection('users').doc(userId)
          .collection('devices').orderBy('lastSeen', 'desc').limit(1).get();
        if (!devSnap.empty) {
          clientIdentity = devSnap.docs[0].data().identity;
          _lastRegisteredIdentity = devSnap.docs[0].data();
        }
      } catch(e) { console.error('[Voice] makeCall Firestore error:', e.message); }
    }

    const callerId = process.env.TWILIO_CALLER_ID || '+40373805828';
    const BASE = process.env.PUBLIC_URL || 'http://46.225.182.127';

    console.log(`[Voice] makeCall: from=${callerId} to=${to} agent=${clientIdentity}`);

    // Single call to external — when answered, bridge to VoIP client
    const call = await twilioClient.calls.create({
      to: to,
      from: callerId,
      url: `${BASE}/api/voice/bridge-to-agent?identity=${encodeURIComponent(clientIdentity || '')}`,
      statusCallback: `${BASE}/api/voice/status`,
      statusCallbackEvent: ['answered', 'completed'],
      statusCallbackMethod: 'POST',
      timeout: 30,
    });

    console.log(`[Voice] makeCall SID: ${call.sid}`);

    // Track this SID for FCM
    _confAgentSids.add(call.sid);

    res.json({ success: true, callSid: call.sid });
  } catch(e) {
    console.error('[Voice] makeCall error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// Bridge TwiML — when external picks up, connect to agent VoIP client
app.post('/api/voice/bridge-to-agent', (req, res) => {
  const identity = req.query.identity || req.body.identity || '';
  const twiml = new twilio.twiml.VoiceResponse();
  console.log(`[Voice] bridge-to-agent: connecting to ${identity}`);

  if (identity) {
    const dial = twiml.dial({
      callerId: process.env.TWILIO_CALLER_ID || '+40373805828',
      timeout: 30,
    });
    dial.client(identity);
  } else {
    twiml.say({ language: 'ro-RO' }, 'Ne pare rau, operatorul nu este disponibil.');
    twiml.hangup();
  }

  res.type('text/xml').send(twiml.toString());
})

app.post('/api/voice/registerDevice', async (req, res) => {
  const { userId, deviceId, fcmToken } = req.body;
  if (!userId || !deviceId || !fcmToken) {
    return res.status(400).json({ error: 'Missing: userId, deviceId, fcmToken' });
  }
  const identity = `user_${userId}_dev_${deviceId}`;
  try {
    await db.collection('users').doc(userId).collection('devices').doc(deviceId)
      .set({ identity, fcmToken, userId, deviceId,
             lastSeen: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    _lastRegisteredIdentity = { identity, userId, deviceId };
    console.log(`[Voice] Device registered: ${identity}`);
    res.json({ identity });
  } catch (e) {
    console.error('[Voice] registerDevice error:', e.message);
    res.status(500).json({ error: 'Internal error' });
  }
});

// ── 6. GET VOIP TOKEN (Flutter app → server to get Twilio access token) ───────
app.get('/api/voice/getVoipToken', async (req, res) => {
  const { userId, deviceId } = req.query;
  if (!userId || !deviceId) {
    return res.status(400).json({ error: 'Missing: userId, deviceId' });
  }
  try {
    const devDoc = await db.collection('users').doc(userId).collection('devices').doc(deviceId).get();
    if (!devDoc.exists) return res.status(404).json({ error: 'device-not-registered' });
    const identity = devDoc.data().identity;

    const AccessToken = twilio.jwt.AccessToken;
    const VoiceGrant = AccessToken.VoiceGrant;
    const voiceGrant = new VoiceGrant({
      outgoingApplicationSid: process.env.TWIML_APP_SID,
      incomingAllow: true,
      pushCredentialSid: process.env.TWILIO_PUSH_CREDENTIAL_SID || 'CR45fcd9835719e90895bf551b87e4ef48',
    });
    const token = new AccessToken(
      process.env.TWILIO_SID,
      process.env.TWILIO_API_KEY_SID,
      process.env.TWILIO_API_KEY_SECRET,
      { identity, ttl: 3600 }
    );
    token.addGrant(voiceGrant);
    const jwt = token.toJwt();
    console.log(`[Voice] VoIP token issued for ${identity}`);
    res.json({ token: jwt, identity });
  } catch (e) {
    console.error('[Voice] getVoipToken error:', e.message);
    res.status(500).json({ error: 'Token generation failed' });
  }
});

// ── 7. CALL HISTORY (Flutter app reads call logs) ─────────────────────────────
app.get('/api/voice/calls', async (req, res) => {
  try {
    const snap = await db.collection('calls').orderBy('timestamp', 'desc').limit(50).get();
    const calls = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(calls);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/voice/calls/:sid', async (req, res) => {
  try {
    const doc = await db.collection('calls').doc(req.params.sid).get();
    if (!doc.exists) return res.status(404).json({ error: 'Not found' });
    res.json({ id: doc.id, ...doc.data() });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/voice/recording/:sid', async (req, res) => {
  try {
    const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
    const rec = await client.recordings(req.params.sid).fetch();
    res.json({ url: `https://api.twilio.com${rec.mediaUrl}`, duration: rec.duration });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

;


app.all('/DEBUG_TEST', (req, res) => {
  res.send(`DEBUG: Running index.js in ${process.cwd()}`);
});

// DEBUG: Trigger profile pic backfill
app.get('/debug/fetch-avatars/:docId', requireAdminToken, async (req, res) => {
  const { docId } = req.params;
  try {
    const result = await sessionManager.backfillProfilePictures(docId);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// DEBUG: Trigger profile pic backfill
app.get('/debug/fetch-avatars/:docId', requireAdminToken, async (req, res) => {
  const { docId } = req.params;
  try {
    const result = await sessionManager.backfillProfilePictures(docId);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});


// --- API Aliases for Flutter App ---
app.use((req, res, next) => {
  // Debug log for API routes
  if (req.url.startsWith('/api/conversations')) {
    console.log(`[API Debug] Hit: ${req.method} ${req.url}`);
  }
  next();
});

// ─── POST /api/conversations — Create or find a conversation ───
// Called from Flutter when user taps "Open conversation on WhatsApp"
// Body: { phone: "+407...", accountId: "docId", label: "Client Name" }
// Returns: { conversationId, jid }
app.post("/api/conversations", async (req, res) => {
  const { phone, accountId, label } = req.body;
  console.log(`[OpenConvo] Request: phone=${phone} accountId=${accountId} label=${label}`);

  if (!phone || !accountId) {
    return res.status(400).json({ error: "phone and accountId are required" });
  }

  // 1) Normalize phone → JID
  let digits = String(phone).replace(/[^0-9]/g, '');
  // If starts with 0 and looks Romanian (10 digits), prepend 40
  if (digits.startsWith('0') && digits.length === 10) {
    digits = '40' + digits.substring(1);
  }
  // Remove leading + if it snuck through
  if (digits.startsWith('+')) digits = digits.substring(1);

  if (digits.length < 8 || digits.length > 15) {
    return res.status(400).json({ error: "invalid_phone", message: `Invalid phone number: ${phone}` });
  }

  const jid = digits + '@s.whatsapp.net';
  // ── Canonical JID: ensure we use the same ID as inbound messages ──
  const canonicalJid = resolveCanonicalJid(jid);
  const convoId = `${accountId}_${canonicalJid}`;
  console.log(`[OpenConvo] Normalized: jid=${jid} canonical=${canonicalJid} convoId=${convoId}`);

  // 2) Check session
  const session = sessionManager.sessions.get(accountId);
  if (!session || session.status !== 'connected') {
    return res.status(503).json({
      error: "no_active_session",
      accountId,
      message: "No active WhatsApp session for this account. Please scan QR first."
    });
  }

  try {
    // 3) Get or create conversation in Firestore
    const convoRef = db.collection('conversations').doc(convoId);
    const convoSnap = await convoRef.get();

    if (!convoSnap.exists) {
      console.log(`[OpenConvo] Creating new conversation: ${convoId}`);
      await convoRef.set({
        jid: canonicalJid,
        canonicalJid: canonicalJid,
        phone: '+' + digits,
        accountId,
        accountLabel: session.label || '',
        name: label || null,
        pushName: label || null,
        createdAt: new Date(),
        lastMessageAt: new Date(),
        lastMessagePreview: '',
        unreadCount: 0,
      });
    } else {
      console.log(`[OpenConvo] Conversation exists: ${convoId}`);
      // Update name/label if provided and different
      if (label) {
        await convoRef.set({ name: label, pushName: label }, { merge: true });
      }
    }

    console.log(`[OpenConvo] Success: conversationId=${convoId}`);
    return res.json({ conversationId: convoId, jid, canonicalJid });
  } catch (err) {
    console.error('[OpenConvo] Error:', err);
    return res.status(500).json({ error: "internal_error", message: err.message });
  }
});
app.get("/api/conversations/:jid/messages", (req, res) => {
  const { jid } = req.params;
  console.log(`[API Alias] GET /api/conversations/${jid}/messages -> Rewriting to /messages/${jid}`);
  req.url = `/messages/${encodeURIComponent(jid)}`;
  req.originalUrl = req.url;
  app.handle(req, res);
});

app.post("/api/conversations/:jid/messages", (req, res) => {
  const { jid } = req.params;
  console.log(`[API Alias] POST /api/conversations/${jid}/messages -> Rewriting to /messages/${jid}`);
  req.url = `/messages/${encodeURIComponent(jid)}`;
  req.originalUrl = req.url;
  app.handle(req, res);
});

// --- JWT Helper (Unsafe Decode for MVP) ---
function getEmailFromToken(req) {
  // Return email from already-verified user (set by verifyFirebaseToken middleware)
  if (req.user && req.user.email) return req.user.email;
  
  // Fallback: decode WITHOUT verification — only for logging/non-critical use.
  // SECURITY: NEVER use this for authorization decisions!
  try {
    const auth = req.headers['authorization'];
    if (!auth) return null;
    const token = auth.split(' ')[1];
    if (!token) return null;
    const payload = token.split('.')[1];
    if (!payload) return null;
    const decoded = JSON.parse(Buffer.from(payload, 'base64').toString());
    return decoded.email || null;
  } catch (e) {
    return null;
  }
}

// ── Secure admin middleware: verifyIdToken + role check ────────────────
async function requireAdminSecure(req, res, next) {
  // 1. Try admin token (for CLI/scripts — should be rotated regularly)
  const auth = req.headers.authorization;
  const qToken = req.query.token;
  const token = (auth && auth.startsWith('Bearer ') ? auth.split('Bearer ')[1] : null) || qToken;
  if (token === ADMIN_TOKEN) return next();
  
  // 2. Verify Firebase ID token (cryptographic verification)
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'unauthorized', message: 'Missing Bearer token' });
  }
  try {
    const idToken = auth.split('Bearer ')[1];
    const decoded = await admin.auth().verifyIdToken(idToken);
    req.user = decoded;
    const email = decoded.email;
    
    // Master admin bypass
    if (email === 'ursache.andrei1995@gmail.com') return next();
    
    // Check employees collection for admin role
    const snap = await db.collection('employees').where('email', '==', email).limit(1).get();
    if (!snap.empty && snap.docs[0].data().role === 'admin') return next();
    
    return res.status(403).json({ error: 'forbidden', message: 'Admin role required' });
  } catch (e) {
    return res.status(401).json({ error: 'unauthorized', message: 'Invalid token' });
  }
}

// ── Person Code Generator (atomic, case-insensitive unique) ────────────
// crypto already imported at top of file

async function generatePersonCode() {
  // Retry loop with uniqueness check (case-insensitive)
  for (let attempt = 0; attempt < 20; attempt++) {
    const code = 'SP-' + crypto.randomBytes(2).toString('hex').toUpperCase();
    // Case-insensitive check: Firestore is case-sensitive, so we store UPPERCASE only
    const dup = await db.collection('employees').where('personCode', '==', code).limit(1).get();
    if (dup.empty) return code;
  }
  // Fallback: 6-char code (65K possibilities)
  return 'SP-' + crypto.randomBytes(3).toString('hex').toUpperCase();
}

// ── Audit Logger ─────────────────────────────────────────────────────
async function auditLog(action, details) {
  try {
    await db.collection('audit_log').add({
      action,
      ...details,
      timestamp: new Date(),
    });
  } catch (e) {
    console.error('[Audit] Failed to write:', e.message);
  }
}

// DEPRECATED: Use requireAdminSecure instead.
// This middleware uses INSECURE JWT decode for the email check.
// Kept only for backward compat on routes that also accept ADMIN_TOKEN.
async function requireAdmin(req, res, next) {
  // First try admin token (for CLI/scripts)
  const auth = req.headers.authorization;
  const qToken = req.query.token;
  const token = (auth && auth.startsWith('Bearer ') ? auth.split('Bearer ')[1] : null) || qToken;
  if (token === ADMIN_TOKEN) return next();
  
  // Use secure verification
  return requireAdminSecure(req, res, next);
}

// ── Admin: Set/Change personCode ─────────────────────────────────────
app.post('/api/admin/set-code', requireAdmin, async (req, res) => {
  try {
    const { docId, personCode } = req.body;
    if (!docId || !personCode) return res.status(400).json({ error: 'docId and personCode required' });
    
    // Normalize: trim whitespace, keep original case
    const normalized = personCode.trim();
    if (normalized.length < 1 || normalized.length > 50) {
      return res.status(400).json({ error: 'Codul trebuie sa aiba intre 1 si 50 caractere' });
    }
    
    // Check uniqueness
    const dup = await db.collection('employees').where('personCode', '==', normalized).limit(1).get();
    if (!dup.empty && dup.docs[0].id !== docId) {
      return res.status(409).json({ error: 'code_taken', takenBy: dup.docs[0].data().displayName });
    }
    
    const docRef = db.collection('employees').doc(docId);
    const oldDoc = await docRef.get();
    const oldCode = oldDoc.exists ? oldDoc.data().personCode : null;
    
    await docRef.set({ personCode: normalized, updatedAt: new Date() }, { merge: true });
    await auditLog('personCode.changed', { oldCode, newCode: normalized, docId, adminEmail: getEmailFromToken(req) });
    
    console.log(`[PersonCode] Changed ${oldCode} -> ${normalized} for ${docId}`);
    res.json({ ok: true, personCode: normalized });
  } catch (e) {
    console.error('[Admin] set-code error:', e);
    res.status(500).json({ error: e.message });
  }
});

// ── Admin: Toggle employee permission ────────────────────────────────
app.post('/api/admin/toggle-permission', requireAdmin, async (req, res) => {
  try {
    const { docId, permission, value } = req.body;
    if (!docId || !permission) return res.status(400).json({ error: 'docId and permission required' });
    
    const validPerms = ['canNoteEvents', 'canViewAllChats', 'canManageAccounts'];
    if (!validPerms.includes(permission)) {
      return res.status(400).json({ error: `Invalid permission. Valid: ${validPerms.join(', ')}` });
    }
    
    await db.collection('employees').doc(docId).set({ 
      [permission]: value === true,
      updatedAt: new Date() 
    }, { merge: true });
    
    await auditLog('permission.changed', { docId, permission, value, adminEmail: getEmailFromToken(req) });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});


// Employee Routes (Injected Fix)
app.get('/api/employees/me', async (req, res) => {
  const email = getEmailFromToken(req);
  console.log('GET /employees/me', email);
  
  if (!email) return res.status(401).json({ error: "No email in token" });

  try {
    const snapshot = await db.collection('employees').where('email', '==', email).limit(1).get();
    
    if (snapshot.empty) {
       // Automatic fallback for master admin if not in DB
       if (email === 'ursache.andrei1995@gmail.com') return res.json({ approved: true, role: 'admin', email });
       return res.json({ approved: false, role: 'user', email });
    }

    const data = snapshot.docs[0].data();
    return res.json({
      approved: data.approved === true,
      role: data.role || 'user',
      email: data.email || email,
      displayName: data.displayName,
      personCode: data.personCode || null,
      permissions: {
        canNoteEvents: data.canNoteEvents === true,
        canViewAllChats: data.canViewAllChats === true,
        canManageAccounts: data.canManageAccounts === true,
      }
    });

  } catch (e) {
    console.error('Error in /employees/me:', e);
    // Fallback
    if (email === 'ursache.andrei1995@gmail.com') return res.json({ approved: true, role: 'admin', email, personCode: 'SP-ADMIN', permissions: { canNoteEvents: true, canViewAllChats: true, canManageAccounts: true } });
    res.status(500).json({ error: e.toString() });
  }
});

app.post('/api/employees/request', async (req, res) => {
  const email = getEmailFromToken(req);
  console.log('POST /employees/request', email, req.body);
  const { displayName, phone } = req.body;

  if (!email) return res.status(401).json({ error: "No email" });

  try {
     const snapshot = await db.collection('employees').where('email', '==', email).limit(1).get();
     
     if (!snapshot.empty) {
        const doc = snapshot.docs[0];
        await doc.ref.set({ 
           displayName: displayName || doc.data().displayName,
           phone: phone || doc.data().phone,
           lastLogin: new Date()
        }, { merge: true });
        return res.json({ status: doc.data().approved ? 'approved' : 'pending' });
     }

     const isMasterAdmin = (email === 'ursache.andrei1995@gmail.com');
     await db.collection('employees').add({
       email,
       displayName,
       phone,
       role: isMasterAdmin ? 'admin' : 'employee',
       approved: isMasterAdmin,
       createdAt: new Date(),
       uid: req.body.uid || ''
     });

     return res.json({ status: isMasterAdmin ? 'approved' : 'pending' });

  } catch (e) {
    console.error('Error requesting access:', e);
    res.status(500).json({ error: e.toString() });
  }
});

import { getAuth } from "firebase-admin/auth";


// --- Admin Employee Management ---
app.get('/api/employees', async (req, res) => {
  try {
     const snapshot = await db.collection('employees').where('approved', '==', true).get(); 
     const employees = [];
     snapshot.forEach(doc => {
         const d = doc.data();
         employees.push({ 
           docId: doc.id,
           displayName: d.displayName,
           email: d.email,
           role: d.role,
           personCode: d.personCode || null,
           permissions: {
             canNoteEvents: d.canNoteEvents === true,
             canViewAllChats: d.canViewAllChats === true,
             canManageAccounts: d.canManageAccounts === true,
           }
         });
     });
     res.json(employees);
  } catch(e) {
      console.error("Error listing employees:", e);
      res.status(500).json({error: e.message});
  }
});

app.get('/api/employees/requests', async (req, res) => {
  try {
     const snapshot = await db.collection('employees').get(); 
     const requests = [];
     snapshot.forEach(doc => {
         const data = doc.data();
         // Only true "new" requests: not approved AND not suspended
         if (data.approved !== true && data.suspended !== true) {
             requests.push({ docId: doc.id, ...data });
         }
     });
     res.json(requests);
  } catch(e) {
      console.error("Error listing requests:", e);
      res.status(500).json({error: e.message});
  }
});

app.get('/api/employees/suspended', async (req, res) => {
  try {
     const snapshot = await db.collection('employees').where('suspended', '==', true).get(); 
     const suspended = [];
     snapshot.forEach(doc => {
         suspended.push({ docId: doc.id, ...doc.data() });
     });
     res.json(suspended);
  } catch(e) {
      console.error("Error listing suspended:", e);
      res.status(500).json({error: e.message});
  }
});

app.post('/api/employees/:uid/approve', requireAdmin, async (req, res) => {
    try {
        const { uid } = req.params;

        // 1. Get current data to find email
        const docRef = db.collection('employees').doc(uid); // uid here is actually docId from params
        const docSnap = await docRef.get();
        if (!docSnap.exists) {
            return res.status(404).json({error: "Employee not found"});
        }
        const empData = docSnap.data();
        const email = empData.email;

        // 2. Update Firestore Employee Doc (personCode set separately by admin)
        await docRef.set({ 
            approved: true,
            suspended: false, // Clear suspension
            role: 'employee',
            approvedAt: new Date()
        }, { merge: true });

        // 3. Set Custom Claim & CREATE USER PROFILE
        let authUid = empData.uid; // Try existing field
        console.log(`[Auth] Attempting claim for docId=${uid}, email=${email}, existingAuthUid=${authUid}`);
        
        try {
             let userRecord;
             // Try getting via UID if we have it
             if (authUid) {
                 try { 
                    userRecord = await getAuth().getUser(authUid); 
                    console.log(`[Auth] Found user via existing UID: ${authUid}`);
                 } catch(e) {
                    console.log(`[Auth] Failed lookup by existing UID ${authUid}: ${e.message}`);
                 }
             }
             
             // Fallback to email lookup
             if (!userRecord && email) {
                 try {
                    userRecord = await getAuth().getUserByEmail(email);
                    authUid = userRecord.uid;
                    console.log(`[Auth] Found user via Email ${email}: ${authUid}`);
                    // Save access to real UID in employee doc
                    await docRef.set({ uid: authUid }, { merge: true }); 
                 } catch(e) {
                    console.error(`[Auth] Failed lookup by Email ${email}: ${e.message}`);
                 }
             }

             if (userRecord) {
                 // A. Set Claims
                 await getAuth().setCustomUserClaims(userRecord.uid, { approved: true, role: 'employee' });
                 console.log(`[Auth] SUCCESS: Custom claims set for email ${email} (uid: ${userRecord.uid})`);

                 // B. CREATE USER PROFILE IN 'users' COLLECTION
                 // This ensures the "Profile" exists as requested by user
                 await db.collection('users').doc(userRecord.uid).set({
                    email: email,
                    displayName: empData.displayName || '',
                    phone: empData.phone || '',
                    role: 'employee',
                    approved: true,
                    createdAt: empData.createdAt || new Date(),
                    photoURL: userRecord.photoURL || '',
                    uid: userRecord.uid
                 }, { merge: true });
                 console.log(`[Profile] Created/Updated user profile for ${userRecord.uid}`);

             } else {
                 console.error(`[Auth] FATAL: Could not find Auth User for doc ${uid} / email ${email}`);
             }
        } catch (authErr) {
            console.error(`[Auth] Unexpected error setting claims/profile:`, authErr);
            // DO NOT THROW. Proceed to return success for Firestore update.
        }

        res.json({ status: 'approved', docId: uid, authUid });
    } catch(e) {
        console.error("Error approving:", e);
        res.status(500).json({error: e.message});
    }
});

app.post('/api/employees/:uid/suspend', requireAdmin, async (req, res) => {
    try {
        const { uid } = req.params;
        await db.collection('employees').doc(uid).set({ 
            approved: false,
            suspended: true,
            suspendedAt: new Date()
        }, { merge: true });

        // Remove Claim
        try {
             await getAuth().setCustomUserClaims(uid, { approved: false });
        } catch (e) { /* ignore */ }

        res.json({ status: 'suspended', uid });
    } catch(e) {
        console.error("Error suspending:", e);
        res.status(500).json({error: e.message});
    }
});

app.post('/api/employees/:uid/reject', requireAdmin, async (req, res) => {
    try {
        const { uid } = req.params;
        await db.collection('employees').doc(uid).set({ 
            approved: false,
            rejectedAt: new Date()
        }, { merge: true });

        // Remove Claim
        try {
             await getAuth().setCustomUserClaims(uid, { approved: false });
        } catch (e) { /* ignore */ }

        res.json({ status: 'rejected', uid });
    } catch(e) {
        console.error("Error rejecting:", e);
        res.status(500).json({error: e.message});
    }
});

app.get("/ping", (req, res) => res.send("pong " + Date.now()));

/* ========== Helpers for Normalization ========== */
function normalizeTs(val) {
  if (!val) return 0;
  if (typeof val === 'number') return val;
  if (typeof val === 'string') {
    const n = Number(val);
    return Number.isNaN(n) ? 0 : n;
  }
  if (typeof val === 'object' && val !== null) {
    if ('low' in val) return Number(val.low) || 0;
    if ('_seconds' in val) return Number(val._seconds) || 0;
    for (const k of Object.keys(val)) {
      const n = Number(val[k]);
      if (!Number.isNaN(n) && n > 0) return n;
    }
  }
  return 0;
}

function normalizeUnread(u) {
  if (!u) return 0;
  if (typeof u === 'number') return Math.floor(u);
  if (typeof u === 'string') {
    const n = Number(u);
    return Number.isNaN(n) ? 0 : Math.floor(n);
  }
  if (typeof u === 'object' && u !== null) {
    if ('low' in u) return Number(u.low) || 0;
    for (const k of Object.keys(u)) {
      const n = Number(u[k]);
      if (!Number.isNaN(n)) return Math.floor(n);
    }
  }
  return 0;
}

/* ========== Express Routes ========== */

/* ========== DEBUG ROUTE FOR STORE STATS ========== */
app.get("/debug/store-stats", requireAdminToken, (req, res) => {
  const chatsCount = (store.chats instanceof Map) ? store.chats.size : Object.keys(store.chats || {}).length;
  const messagesCount = (store.messages instanceof Map) ? store.messages.size : Object.keys(store.messages || {}).length;
  const contactsCount = (store.contacts instanceof Map) ? store.contacts.size : Object.keys(store.contacts || {}).length;
  
  res.json({
    chats: chatsCount,
    messages: messagesCount,
    contacts: contactsCount,
    sessions: sessionManager.sessions.size,
    sessionIds: Array.from(sessionManager.sessions.keys())
  });
});

/* ========== API ADAPTERS FOR FLUTTER APP compatibility ========== */
// Flutter expects /api/conversations etc.
app.get("/api/conversations", (req, res) => {
  // redirect to /chats logic
  req.url = "/chats";
  app.handle(req, res);
});



app.get("/status", (req, res) => {
  const sessions = [];
  const sessionsById = {};
  const summary = { connected: 0, needs_qr: 0, qr_ready: 0, regenerating: 0, reconnecting: 0, disconnected: 0, other: 0 };

  if (sessionManager && sessionManager.sessions) {
    sessionManager.sessions.forEach((val, key) => {
      const rstate = sessionManager._regeneratingState?.get(key);
      const entry = {
        docId: key,
        status: val.status,
        qr: !!val.qr,
        qrSeq: val.qrSeq || 0,
        qrUpdatedAt: val.qrUpdatedAt || null,
        phone: val.sock?.user?.id?.split(':')[0] || null,
        label: val.label || '',
        reconnectAttempts: val.reconnectAttempts || 0,
        pairingPhase: rstate?.phase || null,
        pairingStartedAt: rstate?.startedAt ? new Date(rstate.startedAt).toISOString() : null,
        reqId: val.reqId || rstate?.reqId || null,
        requiresQR: !val.sock && val.status === 'needs_qr',
      };
      sessions.push(entry);
      sessionsById[key] = entry;
      if (val.status === 'connected') summary.connected++;
      else if (val.status === 'needs_qr') summary.needs_qr++;
      else if (val.status === 'reconnecting') summary.reconnecting++;
      else if (val.status === 'disconnected') summary.disconnected++;
      else summary.other++;
      if (rstate) {
        if (rstate.phase === 'qr_ready') summary.qr_ready++;
        else if (rstate.phase === 'regenerating') summary.regenerating++;
      }
    });
  }

  res.json({
    status: "ok",
    mode: "multi-session",
    sessions,
    sessionsById,
    summary,
    metrics: sessionManager.metrics || {}
  });
});


// GET /api/accounts/:id/qr - Get raw QR code data (secured, no-cache)
app.get('/api/accounts/:id/qr', requireAdminToken, (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const docId = req.params.id;
  const s = sessionManager.sessions.get(docId);
  const rstate = sessionManager._regeneratingState?.get(docId);
  if (!s) return res.status(404).json({ error: 'Session not found', docId });
  res.json({
    docId,
    status: s.status,
    qr: s.qr || null,
    qrSeq: s.qrSeq || 0,
    qrUpdatedAt: s.qrUpdatedAt || null,
    state: rstate?.phase || (s.status === 'connected' ? 'connected' : 'idle'),
    reqId: s.reqId || rstate?.reqId || null,
  });
});

// --- Pairing UI (secured, JS polling, no auto-refresh, no auto-POST) ---
app.get("/pair", requireAdminToken, (req, res) => {
  const accountId = req.query.accountId || '';
  const token = (req.headers.authorization?.split('Bearer ')[1]) || req.query.token || '';

  res.set('Cache-Control', 'no-store');
  res.send(`<!DOCTYPE html>
<html><head>
  <title>WhatsApp QR Pairing</title>
  <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"><\/script>
  <style>
    body { font-family: -apple-system, sans-serif; padding: 20px; background: #1a1a2e; color: #eee; }
    h1 { color: #e94560; }
    .status { padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: bold; display: inline-block; }
    .status-connected { background: #2ecc71; color: #000; }
    .status-needs_qr { background: #e67e22; color: #fff; }
    .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; margin: 5px; }
    .btn-regen { background: #e94560; color: #fff; }
    .btn-regen:disabled { background: #555; cursor: not-allowed; }
    .seq { font-size: 12px; color: #888; margin-top: 5px; }
    select { padding: 8px; border-radius: 8px; background: #16213e; color: #eee; border: 1px solid #333; }
  </style>
</head>
<body>
  <h1>WhatsApp QR Pairing</h1>
  <p>Select an account, click Regenerate, then scan with WhatsApp Linked Devices.</p>
  <div>
    <label>Account: </label>
    <select id="accountSelect"></select>
    <button class="btn btn-regen" id="regenBtn" onclick="doRegenerate()">Regenerate QR</button>
  </div>
  <div id="qr-display" style="margin-top:20px;"></div>
  <div id="status-display" style="margin-top:10px;"></div>
  <div id="all-accounts" style="margin-top:30px;"></div>

  <script>
    const TOKEN = '${token}';
    const BASE = window.location.origin;
    const headers = TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {};
    let selectedAccount = '${accountId}';
    let currentQrSeq = 0;
    let polling = null;

    async function loadAccounts() {
      try {
        const r = await fetch(BASE + '/status');
        const d = await r.json();
        const sel = document.getElementById('accountSelect');
        sel.innerHTML = '<option value="">-- select --</option>';
        d.sessions.forEach(s => {
          const opt = document.createElement('option');
          opt.value = s.docId;
          opt.textContent = s.docId.substring(0,8) + '... [' + s.status + '] ' + (s.phone || '');
          if (s.docId === selectedAccount) opt.selected = true;
          sel.appendChild(opt);
        });
        const sum = d.summary || {};
        document.getElementById('all-accounts').innerHTML =
          '<h3>All Accounts</h3>' +
          '<p>Connected: ' + (sum.connected||0) +
          ' | Needs QR: ' + (sum.needs_qr||0) +
          ' | Reconnecting: ' + (sum.reconnecting||0) +
          ' | Disconnected: ' + (sum.disconnected||0) + '</p>';
      } catch(e) { console.error('loadAccounts error:', e); }
    }

    async function doRegenerate() {
      const acct = document.getElementById('accountSelect').value;
      if (!acct) return alert('Select an account first');
      selectedAccount = acct;
      const btn = document.getElementById('regenBtn');
      btn.disabled = true;
      btn.textContent = 'Regenerating...';
      try {
        const r = await fetch(BASE + '/api/accounts/' + acct + '/regenerate-qr', { method: 'POST', headers });
        const d = await r.json();
        document.getElementById('status-display').innerHTML = '<pre>' + JSON.stringify(d, null, 2) + '</pre>';
        startPolling(acct);
      } catch(e) {
        document.getElementById('status-display').innerHTML = '<p style="color:red">Error: ' + e.message + '</p>';
      }
      setTimeout(() => { btn.disabled = false; btn.textContent = 'Regenerate QR'; }, 10000);
    }

    function startPolling(acct) {
      if (polling) clearInterval(polling);
      currentQrSeq = 0;
      polling = setInterval(async () => {
        try {
          const r = await fetch(BASE + '/api/accounts/' + acct + '/qr', { headers });
          if (!r.ok) return;
          const d = await r.json();
          if (d.qr && d.qrSeq !== currentQrSeq) {
            currentQrSeq = d.qrSeq;
            const container = document.getElementById('qr-display');
            container.innerHTML = '<div id="qr-canvas"></div>';
            try {
              if (typeof QRCode !== 'undefined') {
                QRCode.toCanvas(document.createElement('canvas'), d.qr, {width: 300, margin: 2}, (err, canvas) => {
                  if (!err) document.getElementById('qr-canvas').appendChild(canvas);
                });
              } else { throw new Error('QRCode not loaded'); }
            } catch(e) {
              var qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' + encodeURIComponent(d.qr);
              document.getElementById('qr-canvas').innerHTML = '<img src=\"' + qrUrl + '\" width=\"300\" height=\"300\" style=\"border-radius:8px;background:#fff;padding:8px\" />';
            }
            container.innerHTML += '<p class="seq">QR #' + d.qrSeq + ' | State: ' + d.state + '</p>';
          }
          document.getElementById('status-display').innerHTML =
            '<p>Status: <span class="status status-' + d.status + '">' + d.status + '</span> | Phase: ' + (d.state||'idle') + '</p>';
          if (d.status === 'connected') {
            clearInterval(polling);
            document.getElementById('qr-display').innerHTML = '<h2 style="color:#2ecc71">CONNECTED!</h2>';
            loadAccounts();
          }
        } catch(e) { console.error('poll error:', e); }
      }, 2000);
    }

    document.getElementById('accountSelect').addEventListener('change', (e) => {
      selectedAccount = e.target.value;
      if (selectedAccount) startPolling(selectedAccount);
    });

    loadAccounts();
    if (selectedAccount) startPolling(selectedAccount);
  <\/script>
</body></html>`);
});

// --- Helper: normalize timestamp extraction
function getMsgTs(m) {
  if (!m) return 0;
  // try many places
  const tsCandidates = [
    m.messageTimestamp,
    m.message && m.message.messageTimestamp,
    m.message && m.message.messageTimestamp?.low,
    m.message && m.message.messageTimestamp?._seconds,
    m.messageTimestamp?.low,
    m.messageTimestamp?._seconds
  ];
  for (const c of tsCandidates) {
    if (c === undefined || c === null) continue;
    if (typeof c === 'number') return Number(c);
    if (typeof c === 'string') {
      const n = Number(c);
      if (!Number.isNaN(n)) return n;
    }
    if (typeof c === 'object') {
      if ('low' in c) return Number(c.low || 0);
      if ('_seconds' in c) return Number(c._seconds || 0);
    }
  }
  return 0;
}

// --- Robust /chats route with DEDUPLICATION
app.get("/chats", (req, res) => {
  try {
    const rawChats = store.chats;
    const unifiedMap = new Map(); // canonicalJid -> { ...mergedData }

    const processChat = (jid, meta) => {
      try {
        if (!jid || jid === '0@s.whatsapp.net') return;
        
        // Resolve canonical (prefer phone number)
        let canonical = resolveCanonicalJid(jid);
        if (!canonical) canonical = jid;

        // Extract metadata
        const unread = normalizeUnread(meta.unreadCount || meta.unread || 0);
        const lastTs = normalizeTs(
          meta.conversationTimestamp?.low || 
          meta.lastMessageRecvTimestamp || 
          meta.conversationTimestamp || 0
        );
        const name = meta.name || meta.subject || meta.notify || '';
        const lastMsgText = meta.lastMessageText || '';
        const lastSender = meta.lastSender || '';

        // If generic name, try to find better name from contact
        let displayName = name;
        if (!displayName) {
           const c = getContact(canonical);
           if (c && (c.name || c.notify)) displayName = c.name || c.notify;
        }

        // Merge or Create
        if (unifiedMap.has(canonical)) {
          const existing = unifiedMap.get(canonical);
          
          // Sum unread
          existing.unread += unread;
          
          // Use latest timestamp and message
          if (lastTs > existing.lastMessage) {
            existing.lastMessage = lastTs;
            existing.lastMessageText = lastMsgText;
            existing.lastSender = lastSender;
          }
          
          // Keep best name
          if (!existing.name && displayName) existing.name = displayName;
          
        } else {
          unifiedMap.set(canonical, {
            id: canonical,
            name: displayName,
            phoneNumber: (canonical.endsWith('@g.us')) ? null : canonical.split('@')[0],
            unread: unread,
            lastMessage: lastTs,
            lastMessageText: lastMsgText,
            lastSender: lastSender
          });
        }
      } catch (e) {
        console.error('Error processing chat:', jid, e);
      }
    };

    // Iterate Store
    if (Array.isArray(rawChats)) {
      for (const entry of rawChats) {
        if (entry && entry[0]) processChat(entry[0], entry[1] || {});
      }
    } else if (rawChats && typeof rawChats === 'object') {
      const entries = rawChats instanceof Map ? Array.from(rawChats.entries()) : Object.entries(rawChats);
      for (const [jid, meta] of entries) {
        processChat(jid, meta);
      }
    }

    // Convert to list
    const list = Array.from(unifiedMap.values());

    // sort desc by lastMessage
    list.sort((a,b) => (b.lastMessage || 0) - (a.lastMessage || 0));
    
    res.json(list);
  } catch (err) {
    console.error('/chats error', err);
    res.status(500).json({ error: err.toString() });
  }
});

// --- Robust /messages/:jid route
app.get("/messages/:jid", (req, res) => {
  const { jid } = req.params;
  const limit = parseInt(req.query.limit) || 1000;
  
  if (!jid) return res.status(400).json({ error: "Missing jid" });

  const canonical = resolveCanonicalJid(jid);
  const partners = findPartnerJids(jid);

  let allMessages = [];
  
  // 1. Pull from store.messages (Map or Object)
  if (store.messages) {
    for (const p of partners) {
       // Also try to update contact name if missing
       if (store.contacts && store.contacts[p]) {
           const c = store.contacts[p];
           // If we have a better name here, we might want to return it? 
           // For now, messages route focuses on messages.
       }

       const msgs = getMessagesForJid(p);
       allMessages = allMessages.concat(msgs);
    }
  }

  // 2. Sort & Dedupe
  const seen = new Set();
  const unique = [];
  
  allMessages.sort((a, b) => {
    const tA = getMsgTs(a);
    const tB = getMsgTs(b);
    return tB - tA; // Newest first
  });

  for (const m of allMessages) {
    if (!m.key || !m.key.id) continue;
    if (seen.has(m.key.id)) continue;
    seen.add(m.key.id);
    unique.push(m);
  }

  // 3. Slice if needed (optimization)
  let result = unique;
  if (limit > 0 && result.length > limit) {
     result = result.slice(0, limit);
  }
  
  // 4. Sort ASC for chat
  result.sort((a, b) => {
     return getMsgTs(a) - getMsgTs(b);
  });

  res.json(result);
});

// --- Media Download Route ---
app.get("/media/:jid/:id", async (req, res) => {
  const { jid, id } = req.params;
  const canonical = resolveCanonicalJid(jid) || jid;
  const requestId = req.id || req.headers['x-request-id'] || `media-${Date.now()}`;
  logMediaOp('GET /media/:jid/:id', { inputJid: jid, canonicalJid: canonical, accountId: null, convoId: null, msgId: id, storagePath: null, requestId });
  
  try {
     // 1. Find message
     const partners = findPartnerJids(jid);
     
     let foundMsg = null;
     if (store.messages) {
        for (const p of partners) {
           const msgs = getMessagesForJid(p);
           const m = msgs.find(x => x.key && x.key.id === id);
           if (m) {
              foundMsg = m;
              break;
           }
        }
     }
     
     if (!foundMsg) {
        return res.status(404).json({ error: "Message not found" });
     }

     // 2. Download
     const logger = pino({ level: 'silent' });
     
     const buffer = await downloadMediaMessage(
        foundMsg,
        'buffer',
        { logger }
     );
     
     if (!buffer) {
        return res.status(404).json({ error: "Empty buffer" });
     }

     // 3. Detect Mime
     let mimetype = 'application/octet-stream';
     let msgContent = foundMsg.message;
     
     if (msgContent) {
        // unwraps
        if (msgContent.message) msgContent = msgContent.message;
        if (msgContent.ephemeralMessage) msgContent = msgContent.ephemeralMessage.message;
        if (msgContent.viewOnceMessage) msgContent = msgContent.viewOnceMessage.message;

        if (msgContent.imageMessage) mimetype = msgContent.imageMessage.mimetype || 'image/jpeg';
        else if (msgContent.videoMessage) mimetype = msgContent.videoMessage.mimetype || 'video/mp4';
        else if (msgContent.documentMessage) mimetype = msgContent.documentMessage.mimetype || 'application/pdf';
        else if (msgContent.stickerMessage) mimetype = msgContent.stickerMessage.mimetype || 'image/webp';
        else if (msgContent.audioMessage) mimetype = msgContent.audioMessage.mimetype || 'audio/mp4';
     }

     res.set('Content-Type', mimetype);
     res.send(buffer);

  } catch (e) {
     console.error("Media download error:", e);
     res.status(500).json({ error: "Download failed", details: e.message });
  }
});


/* ========== Signed URL Endpoint (on-demand, 1h expiry) ========== */
app.get("/api/media/url/:convoId/:msgId", verifyFirebaseToken, async (req, res) => {
  const { convoId, msgId } = req.params;
  const requestId = req.id || req.headers['x-request-id'] || `signed-${Date.now()}`;

  try {
    // Look up message in Firestore to get storage path
    const msgDoc = await db.collection('conversations').doc(convoId).collection('messages').doc(msgId).get();
    if (!msgDoc.exists) return res.status(404).json({ error: 'message_not_found' });

    const data = msgDoc.data();
    const storagePath = data?.media?.path;
    if (!storagePath) return res.status(404).json({ error: 'no_media', message: 'Message has no media.path' });

    logMediaOp('GET /api/media/url', { inputJid: data?.metadata?.originJid, canonicalJid: data?.metadata?.originJid, accountId: null, convoId, msgId, storagePath, requestId });

    const url = await getSignedMediaUrl(storagePath, 3600000); // 1 hour
    if (!url) return res.status(500).json({ error: 'signed_url_failed' });

    res.json({ url, expiresIn: 3600, storagePath });
  } catch (e) {
    console.error('[SignedURL Error]', e);
    res.status(500).json({ error: e.message });
  }
});

/* ========== Outbound Media Endpoint ========== */
app.post("/messages/:jid/media", upload.single('file'), async (req, res) => {
  let jid = req.params.jid;
  const { accountId, caption, type: mediaType } = req.body;
  const requestId = req.id || req.headers['x-request-id'] || `out-media-${Date.now()}`;

  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  if (!jid) return res.status(400).json({ error: 'Missing jid' });

  // Canonicalize JID
  if (jid) jid = jid.replace('+', '');
  const canonicalJid = resolveCanonicalJid(jid) || jid;
  jid = canonicalJid;

  // Find active session
  let sock = null;
  let docId = accountId || null;
  if (docId) {
    const session = sessionManager.sessions.get(docId);
    sock = session?.sock;
  }
  if (!sock) {
    for (const [id, session] of sessionManager.sessions) {
      if (session.sock) { sock = session.sock; docId = id; break; }
    }
  }
  if (!sock) return res.status(503).json({ error: 'No active WhatsApp session' });

  const convoId = docId ? `${docId}_${canonicalJid}` : canonicalJid;
  logMediaOp('POST /messages/:jid/media', { inputJid: req.params.jid, canonicalJid, accountId: docId, convoId, msgId: null, storagePath: null, requestId });

  try {
    // Determine Baileys message type
    const buffer = req.file.buffer;
    const mime = req.file.mimetype;
    const fileName = req.file.originalname;
    let msgPayload;

    const detectedType = mediaType || (mime?.startsWith('image/') ? 'image' : mime?.startsWith('video/') ? 'video' : mime?.startsWith('audio/') ? 'audio' : 'document');

    switch (detectedType) {
      case 'image':
        msgPayload = { image: buffer, caption: caption || undefined, mimetype: mime };
        break;
      case 'video':
        msgPayload = { video: buffer, caption: caption || undefined, mimetype: mime };
        break;
      case 'audio':
        msgPayload = { audio: buffer, mimetype: mime, ptt: mime === 'audio/ogg' };
        break;
      default:
        msgPayload = { document: buffer, mimetype: mime, fileName: fileName || 'file' };
    }

    const sent = await sock.sendMessage(jid, msgPayload);
    const messageId = sent?.key?.id || `local-${Date.now()}`;

    // Upload to Firebase Storage
    const mediaObj = await uploadMediaToStorage(buffer, convoId, messageId, mime, buffer.length, fileName);

    logMediaOp('POST /messages/:jid/media (write)', { inputJid: req.params.jid, canonicalJid, accountId: docId, convoId, msgId: messageId, storagePath: mediaObj?.path, requestId });

    // Sync to Firestore
    const preview = caption || (detectedType === 'image' ? '📷 Photo' : detectedType === 'video' ? '🎥 Video' : '📎 File');
    const syncOptions = { resolveCanonicalJid, messageId };
    if (mediaObj) syncOptions.media = mediaObj;
    await syncMessageToFirestore(sent, jid, preview, null, docId, '', syncOptions);

    res.json({ status: 'sent', messageId, convoId, media: mediaObj || null });
  } catch (e) {
    console.error('[OutboundMedia Error]', e);
    res.status(500).json({ error: e.message });
  }
});

// --- Mark as Read Route
app.post("/chats/:jid/read", async (req, res) => {
  const { jid } = req.params;
  try {
    const partners = findPartnerJids(jid);
    let updated = 0;

    // Helper to clear unread
    const clearUnread = (targetJid) => {
      if (store.chats && Array.isArray(store.chats)) {
        for (const entry of store.chats) {
          if (entry[0] === targetJid && entry[1]) {
            entry[1].unreadCount = 0;
            updated++;
          }
        }
      } else if (store.chats && typeof store.chats === 'object') {
        const meta = store.chats[targetJid] || (store.chats.get && store.chats.get(targetJid));
        if (meta) {
          meta.unreadCount = 0;
          updated++;
        }
      }
    };

    partners.forEach(p => clearUnread(p));
    
    res.json({ status: "ok", updated });
  } catch (e) {
    console.error("Error marking read:", e);
    res.status(500).json({ error: e.toString() });
  }
});

// --- NEW: Send Message Route
app.post("/messages/:jid", async (req, res) => {
  let { jid } = req.params;
  let { text, accountId } = req.body; 

  // Normalize JID: WhatsApp Baileys requires pure numeric JIDs.
  // Stripping '+' prevents the duplicate thread bug where outgoing has '+' but incoming network replies don't.
  if (jid) {
      jid = jid.replace('+', '');
  }

  // ── Canonical JID: resolve before sending ──
  jid = resolveCanonicalJid(jid) || jid;

  console.log(`[Send-Debug] Request received for JID: ${jid} (canonical)`);
  console.log(`[Send-Debug] Body:`, JSON.stringify(req.body));

  // PARSE COMPOSITE ID (AccountId_ClientJid) for multi-tenancy
  // If jid starts with a known Account ID, extract it.
  if (!accountId && jid.includes('_')) {
      const parts = jid.split('_');
      const potentialAccId = parts[0];
      // Check if this prefix is a valid, active session
      if (sessionManager.getSession(potentialAccId)) {
          accountId = potentialAccId;
          jid = parts.slice(1).join('_'); // The rest is the real JID
          console.log(`[Send-Debug] Extracted AccountId: ${accountId}, Real JID: ${jid}`);
      }
  }

  if (!text) {
      console.log(`[Send-Debug] Error: Missing text`);
      return res.status(400).json({ error: "Missing text" });
  }

  // 1. Determine which session to use
  let sock = null;

  if (accountId) {
      // Explicit selection
      sock = sessionManager.getSession(accountId);
      if (!sock) console.log(`[Send-Debug] Explicit account ${accountId} not active.`);
      else console.log(`[Send-Debug] Using explicit account session: ${accountId}`);
  } else {
      // Auto-selection (fallback to first connected)
      // Iterate sessions
      for (const [docId, s] of sessionManager.sessions) {
          if (s.status === 'connected' && s.sock) {
              sock = s.sock;
              console.log(`[Send-Debug] Auto-selected session: ${docId}`);
              // Ideally check if this sock has relationship with JID?
              // For now, first available.
              break;
          }
      }
      if (!sock) console.log(`[Send-Debug] No auto-selected session found.`);
  }

  if (!sock) {
      console.log(`[Send-Debug] CRITICAL: No active WhatsApp session found to send message.`);
      return res.status(503).json({ error: "No active WhatsApp session found" });
  }

  try {
    console.log(`[Send-Debug] Request received for JID: ${jid}`);
    console.log(`[Send-Debug] Body:`, JSON.stringify(req.body));

    // Retry logic for groups — Baileys may throw 'forbidden' on groupMetadata
    // right after linking (group data not synced yet)
    let sent;
    const maxRetries = jid.endsWith('@g.us') ? 3 : 1;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        sent = await sock.sendMessage(jid, { text });
        console.log('[Send-Debug] sendMessage result:', JSON.stringify(sent));
        break; // success
      } catch (sendErr) {
        console.log(`[Send-Debug] sendMessage attempt ${attempt}/${maxRetries} failed:`, sendErr.message);
        if (sendErr.message === 'forbidden' && attempt < maxRetries) {
          console.log(`[Send-Debug] Group metadata not synced yet, retrying in 3s...`);
          await new Promise(r => setTimeout(r, 3000));
        } else {
          throw sendErr; // re-throw on last attempt or non-forbidden error
        }
      }
    }

    // Defensive extraction of message id
    const messageId = sent?.key?.id || sent?.id || (sent && sent.message && sent.message.id) || `local-${Date.now()}`;

    // Prepare sync payload
    const originJid = jid;
    const isGroup = originJid.endsWith('@g.us');
    let chatName = isGroup ? null : originJid.split('@')[0];

    if (isGroup) {
      try {
        const groupMetadata = await sock.groupMetadata(originJid);
        if (groupMetadata && groupMetadata.subject) chatName = groupMetadata.subject;
      } catch (e) {
        console.log(`[Send] Failed to fetch metadata for ${originJid}:`, e && e.message);
      }
    }

    // Find session doc id & label safely
    let docId = null;
    let label = '';
    for (const [dId, s] of sessionManager.sessions) {
      if (s && s.sock === sock) { docId = dId; label = s.label || ''; break; }
    }

    // Call sync with fallback messageId and full sent object
    try {
      await syncMessageToFirestore(sent, originJid, text, chatName, docId, label, { messageId, resolveCanonicalJid });
    } catch (syncErr) {
      console.error('Error syncing outbound message (non-fatal):', syncErr);
    }

    res.json({ status: 'ok', data: sent });
  } catch (e) {
    console.error('Error sending message:', e && (e.stack || e.toString()));
    res.status(500).json({ error: e.toString() });
  }
});

app.post("/admin/link-lid", requireAdminToken, (req, res) => {
  const { lid, phoneJid } = req.body;
  if (!lid || !phoneJid) return res.status(400).json({ error: "Missing lid or phoneJid" });

  // Update memory
  lidOverrides[lid] = phoneJid;
  saveLidOverrides();

  // Update store contact if exists
  const contact = getContact(lid);
  if (contact) {
    contact.phoneNumber = phoneJid;
    setContact(lid, contact);
  } else {
    setContact(lid, { id: lid, phoneNumber: phoneJid });
  }
  scheduleStoreWrite();

  res.json({ status: "ok", mapped: { [lid]: phoneJid } });
});

app.get("/debug/contact/:id", requireAdminToken, (req, res) => {
  const c = getContact(req.params.id);
  res.json(c || { error: "Not found" });
});

app.get("/download-store", requireAdminToken, (req, res) => {
  if (fs.existsSync(STORE_FILE)) {
    res.download(STORE_FILE);
  } else {
    res.status(404).json({ error: "Store file not found" });
  }
});

app.get("/debug/name-resolution/:jid", requireAdminToken, (req, res) => {
  const { jid } = req.params;
  const candidates = findPartnerJids(jid);
  let msgs = [];
  for(const k of candidates) {
     msgs = msgs.concat(getMessagesForJid(k));
  }
  msgs.sort((a,b) => (b.messageTimestamp || 0) - (a.messageTimestamp || 0));
  
  const sample = msgs.slice(0, 20).map(m => ({
    key: m.key,
    pushName: m.pushName,
    verifiedBizName: m.verifiedBizName,
    fromMe: m.key ? m.key.fromMe : 'unknown',
    ts: m.messageTimestamp
  }));
  
  res.json({
    jid,
    candidates,
    totalMessages: msgs.length,
    sample
  });
});

/* ===== ACCOUNT MANAGEMENT API ===== */

// GET /api/wa-accounts - List accounts
app.get("/api/wa-accounts", (req, res) => {
  const accounts = [];
  sessionManager.sessions.forEach((val, key) => {
      accounts.push({
          id: key,
          label: val.label || key, // We might need to fetch label from Firestore if not in memory
          status: val.status,
          phoneNumber: val.sock?.user?.id?.split(':')[0] || ''
      });
  });
  res.json(accounts);
});


// POST /api/accounts/:id/regenerate-qr - Secured + rate limited
app.post("/api/accounts/:id/regenerate-qr", requireAdminToken, regenRateLimit, async (req, res) => {
  const docId = req.params.id;
  const force = req.query.force === 'true';
  const ip = req.ip || req.connection?.remoteAddress || '?';
  const ua = (req.headers['user-agent'] || '').substring(0, 60);
  console.log(`[HTTP] POST /regenerate-qr docId=${docId} force=${force} ip=${ip} ua=${ua}`);
  try {
    const result = await sessionManager.regenerateQR(docId, { force, ip, ua });
    const httpCode = result.status === 'cooldown' ? 429 : 200;
    res.status(httpCode).json({ ok: true, ...result });
  } catch (e) {
    console.error("[regenerate-qr] Error:", e);
    res.status(500).json({ error: e.message });
  }
});

// POST /api/admin/regenerate-all - Bulk regenerate with concurrency control
app.post("/api/admin/regenerate-all", requireAdminToken, async (req, res) => {
  const concurrency = Math.min(parseInt(req.query.concurrency) || 2, 5);
  const results = [];
  const accounts = [];

  sessionManager.sessions.forEach((val, key) => {
    if (val.status === 'needs_qr' || val.status === 'disconnected') accounts.push(key);
  });

  try {
    const snap = await db.collection('wa_accounts').where('status', 'in', ['needs_qr', 'disconnected', 'logged_out']).get();
    snap.forEach(doc => { if (!accounts.includes(doc.id)) accounts.push(doc.id); });
  } catch (e) {
    console.error('[regenerate-all] Firestore error:', e.message);
  }

  console.log(`[Admin] regenerate-all: ${accounts.length} accounts, concurrency=${concurrency}`);

  for (let i = 0; i < accounts.length; i += concurrency) {
    const batch = accounts.slice(i, i + concurrency);
    const batchResults = await Promise.allSettled(
      batch.map(async (docId) => {
        try {
          const result = await sessionManager.regenerateQR(docId, { ip: req.ip || '?', ua: 'admin-bulk' });
          return { docId, ...result };
        } catch (e) {
          return { docId, status: 'error', error: e.message };
        }
      })
    );
    for (const r of batchResults) {
      results.push(r.status === 'fulfilled' ? r.value : { docId: '?', status: 'error', error: r.reason?.message });
    }
    if (i + concurrency < accounts.length) {
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }

  res.json({
    ok: true,
    total: accounts.length,
    results,
    summary: {
      regenerating: results.filter(r => r.status === 'regenerating').length,
      already_regenerating: results.filter(r => r.status === 'already_regenerating').length,
      cooldown: results.filter(r => r.status === 'cooldown').length,
      error: results.filter(r => r.status === 'error').length,
    }
  });
});

/* ===== SECURE AUTH MIDDLEWARE & RESERVE ROUTES ===== */

// Secure Firebase token verification middleware
async function verifyFirebaseToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'unauthenticated', message: 'Missing Bearer token' });
  }
  const token = authHeader.split('Bearer ')[1];
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = decoded; // decoded.uid available
    return next();
  } catch (e) {
    console.error('Token verify error:', e && e.stack ? e.stack : e);
    return res.status(401).json({ error: 'unauthenticated', message: 'Invalid token' });
  }
}

/**
 * POST /api/conversations/:id/reserve
 * Regex route to accept @ in id (groups, phones, lids)
 * Requires Authorization: Bearer <idToken>
 */
app.post(/^\/api\/conversations\/(.+)\/reserve$/, verifyFirebaseToken, async (req, res) => {
  const convoId = req.params[0];
  const uid = req.user && req.user.uid;
  if (!uid) return res.status(401).json({ error: 'unauthenticated', message: 'Missing uid' });

  const ttlMinutes = parseInt(req.body.ttlMinutes, 10) || 15;
  const reservedUntilTs = admin.firestore.Timestamp.fromMillis(Date.now() + ttlMinutes * 60 * 1000);
  const convoRef = db.collection('conversations').doc(convoId);

  try {
    await db.runTransaction(async (t) => {
      const snap = await t.get(convoRef);
      if (!snap.exists) throw new Error('conversation_not_found');

      const existingReservedBy = snap.get('reservedBy') || null;
      const existingReservedUntil = snap.get('reservedUntil') || null;

      // Refresh if same user
      if (existingReservedBy && existingReservedBy === uid) {
        t.update(convoRef, {
          reservedBy: uid,
          reservedAt: admin.firestore.FieldValue.serverTimestamp(),
          reservedUntil: reservedUntilTs
        });
        return;
      }

      // If reserved by another user and not expired -> conflict
      if (existingReservedBy && existingReservedBy !== uid) {
        if (existingReservedUntil && typeof existingReservedUntil.toMillis === 'function') {
          const existingUntilMs = existingReservedUntil.toMillis();
          if (existingUntilMs > Date.now()) {
            throw new Error('already_reserved');
          }
          // expired -> allow reservation
        } else {
          throw new Error('already_reserved');
        }
      }

      // not reserved or expired -> set reservation
      t.update(convoRef, {
        reservedBy: uid,
        reservedAt: admin.firestore.FieldValue.serverTimestamp(),
        reservedUntil: reservedUntilTs
      });
    });

    console.log('[RESERVE] convo=%s by=%s ttlMinutes=%d', convoId, uid, ttlMinutes);
    return res.json({ ok: true, convoId, reservedBy: uid, ttlMinutes });
  } catch (err) {
    console.error('[RESERVE FAILED] convo=%s err=%s', convoId, err && err.message, err);
    if (err.message === 'conversation_not_found') return res.status(404).json({ error: 'conversation_not_found' });
    if (err.message === 'already_reserved') return res.status(409).json({ error: 'already_reserved' });
    return res.status(500).json({ error: 'Failed to reserve', message: err.message || String(err) });
  }
});

/**
 * GET /api/conversations/:id/reservation
 * Debug helper to return reservation status (UI-friendly)
 */
app.get(/^\/api\/conversations\/(.+)\/reservation$/, async (req, res) => {
  const convoId = req.params[0];
  try {
    const doc = await db.collection('conversations').doc(convoId).get();
    if (!doc.exists) return res.status(404).json({ error: 'conversation_not_found' });
    const d = doc.data();
    return res.json({
      reservedBy: d.reservedBy || null,
      reservedAt: d.reservedAt ? d.reservedAt.toDate().toISOString() : null,
      reservedUntil: d.reservedUntil ? d.reservedUntil.toDate().toISOString() : null
    });
  } catch (err) {
    console.error('GET reservation error', err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

/* ===== END SECURE AUTH & RESERVE ===== */

/* ===== COMPLIANCE & PRIVACY APIS (GDPR/Play Safety) ===== */

/**
 * POST /api/user/consent
 * Stores user consent for call recording/data processing.
 */
app.post('/api/user/consent', verifyFirebaseToken, async (req, res) => {
  try {
    const uid = req.user.uid;
    const { consentVersion, userAgent } = req.body;
    
    await db.collection('users').doc(uid).collection('consents').add({
      consentVersion: consentVersion || 'v1',
      userAgent: userAgent || req.headers['user-agent'] || 'unknown',
      ip: req.ip,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      type: 'employee_recording_agreement'
    });

    // Also update main user profile with latest consent
    await db.collection('users').doc(uid).set({
      latestConsentVersion: consentVersion || 'v1',
      consentGivenAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    res.json({ status: 'ok' });
  } catch (e) {
    console.error("Error saving consent:", e);
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/user/deletion-request
 * Creates a ticket for data deletion.
 */
app.post('/api/user/deletion-request', verifyFirebaseToken, async (req, res) => {
  try {
    const uid = req.user.uid;
    const { reason } = req.body;

    const ticketRef = await db.collection('deletion_requests').add({
      uid,
      email: req.user.email || 'unknown',
      reason: reason || 'user_request',
      status: 'pending',
      requestedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    res.json({ status: 'received', ticketId: ticketRef.id });
  } catch (e) {
    console.error("Error creating deletion request:", e);
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/user/privacy-settings
 * Updates user privacy preferences (e.g. AI analysis).
 */
app.post('/api/user/privacy-settings', verifyFirebaseToken, async (req, res) => {
  try {
    const uid = req.user.uid;
    // explicit check for boolean to allow false
    const { aiAnalysisEnabled } = req.body;

    if (aiAnalysisEnabled === undefined) {
      return res.status(400).json({ error: "Missing aiAnalysisEnabled" });
    }

    await db.collection('users').doc(uid).set({
      privacySettings: {
        aiAnalysisEnabled: !!aiAnalysisEnabled,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }
    }, { merge: true });

    res.json({ status: 'updated', aiAnalysisEnabled });
  } catch (e) {
    console.error("Error updating privacy settings:", e);
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /api/user/me
 * Returns the current user's profile (including consent status).
 */
app.get('/api/user/me', verifyFirebaseToken, async (req, res) => {
  try {
    const uid = req.user.uid;
    const doc = await db.collection('users').doc(uid).get();
    
    if (!doc.exists) {
      return res.json({ exists: false, uid });
    }
    
    res.json({ exists: true, ...doc.data() });
  } catch (e) {
    console.error("Error fetching user profile:", e);
    res.status(500).json({ error: e.message });
  }
});

/* ===== END COMPLIANCE APIS ===== */

/* ========== Prometheus /metrics endpoint ========== */
app.get('/metrics', async (req, res) => {
  try {
    res.set('Content-Type', metricsRegistry.contentType);
    res.end(await metricsRegistry.metrics());
  } catch (e) {
    res.status(500).end(e.message);
  }
});

/* Start server & WhatsApp connect (minimal) */
const BIND_HOST = process.env.BIND_HOST || '127.0.0.1';
app.listen(PORT, BIND_HOST, () => {
  logger.info({ port: PORT, host: BIND_HOST }, `API Server running on ${BIND_HOST}:${PORT}`);
  console.log(`API Server running on ${BIND_HOST}:${PORT}`);
});

/* Signal handling for safe shutdown */
process.on('SIGINT', () => {
  console.log('SIGINT received. Saving store...');
  try { store.writeToFile(STORE_FILE); } catch (e) { console.error(e); }
  process.exit(0);
});
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Saving store...');
  try { store.writeToFile(STORE_FILE); } catch (e) { console.error(e); }
  process.exit(0);
});
